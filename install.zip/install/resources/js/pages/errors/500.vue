<template>
    <v-container class="text-center pt-7">
        <h1>500!! server error!!</h1>
    </v-container>
</template>

<script>
export default {};
</script>
